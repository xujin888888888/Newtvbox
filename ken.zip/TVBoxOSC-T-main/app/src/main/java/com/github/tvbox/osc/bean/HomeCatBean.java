package com.github.tvbox.osc.bean;

public class HomeCatBean {
    public boolean isHead;
    public VodInfo historyRecord;
    public Movie.Video homeItem;
}
